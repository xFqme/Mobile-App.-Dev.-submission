# Checkpoint 3 - Covid Form


### Objective -> Create a form and pass data between pages.​

### Code complexity
- Basic/ Fundamental

### Terminologiest in this checkpoint

- Stateless and Stateful Widgets

- ```setState((){})```

- Navigation

### Material widgets involve

- Form​

- TextFormField​

- Radio Button​

- Checkbox​

- Buttons


### TODO 1

- [ ] Play with TextFormField
    - [ ] trigger validator
    - [ ] play with TextInputType
- [ ] Play with Radio Button
- [ ] Play with Checkbox

### TODO 2

- [ ] Add more Text form field
- [ ] Add more Radio Button
- [ ] Add more checkboxes

and send data between page*
