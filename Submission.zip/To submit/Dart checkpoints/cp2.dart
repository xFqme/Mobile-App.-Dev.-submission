void main() {
  String studentName = "Alexander Mohamad";
  List<int> scores = [8,30,17,18];
  // TODO : Add your code here
  var sum=scores.reduce((a, b) => a+b);
  print (studentName+' total score is ' +sum.toString());


}