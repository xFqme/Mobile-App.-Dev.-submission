import 'dart:io';

void main() {
  print("Please answer the questions below");
  print("What is student name");
  String? name = stdin.readLineSync();
  print("How many scores does he/she have?");
  String? scores = stdin.readLineSync();

  print("$name has $scores scores");
}