int calculateTotalScore(List<int> scores) {
    int totalScore = 0;
    for (int score in scores) {
        totalScore += score;
    }
    return totalScore;
}

void main() {
    List<int> scores = [8, 30, 17, 18];
    String studentName = "Alexander Mohamad";
    int totalScore = calculateTotalScore(scores);
    print(studentName+"'s total score is "+totalScore.toString());
 }
