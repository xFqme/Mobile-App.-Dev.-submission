import 'dart:io';

void main() {
  print("Please answer the questions below");
  print("What is student name");
  String? name = stdin.readLineSync();
  print("How many scores does he/she have?");
  String? scores = stdin.readLineSync();
  int grade;
  if(scores?.isEmpty ?? true){
    grade=0;
  } else{
    grade=int.parse(scores ?? '0');
  }
  String rank="E";
  if(grade>=70){
    rank="B";
  } else if (grade>=60){
    rank="C";
  }

  print("$name has $scores scores which is $rank");
}