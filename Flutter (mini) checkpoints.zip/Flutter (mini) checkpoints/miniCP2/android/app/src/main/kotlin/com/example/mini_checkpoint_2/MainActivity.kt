package com.example.mini_checkpoint_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
