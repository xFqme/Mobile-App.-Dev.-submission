package com.example.mini_checkpoint_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
